public class Arquivado extends Estado {
    public Arquivado(){

       // System.out.println("Aquivado");

    }
}
